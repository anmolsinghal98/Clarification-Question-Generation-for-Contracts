1) In the data folder, we provide the final labeled dataset in Ambiguity-Detection-CUAD.csv. The contracts were sourced from Contract Understanding Atticus Dataset (CUAD).
2) We have also provided the manual evaluation of module 1 and 2 generated using ChatGPT. 
3) We provide manually evaluated ChatGPT generated CQs across a subset of 100 sentences sourced from the labeled dataset.  